"use client"

import { CartProvider } from "@/lib/cart-context"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { ProductCard } from "@/components/product-card"
import { products } from "@/lib/products"

export default function Home() {
  return (
    <CartProvider>
      <div className="min-h-screen flex flex-col">
        <Header />
        
        <main className="flex-1">
          {/* Hero Section */}
          <section className="py-16 md:py-24">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
              <div className="max-w-3xl mx-auto text-center">
                <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl font-bold text-foreground leading-tight text-balance">
                  Eviniz İçin Özel Seçilmiş Ürünler
                </h1>
                <p className="mt-6 text-lg text-muted-foreground leading-relaxed text-pretty">
                  El yapımı ve özenle seçilmiş dekoratif ürünlerle yaşam alanlarınızı dönüştürün. 
                  Her ürün benzersiz hikayesiyle sizleri bekliyor.
                </p>
              </div>
            </div>
          </section>

          {/* Products Section */}
          <section id="products" className="pb-16 md:pb-24">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h2 className="font-serif text-2xl md:text-3xl font-bold text-foreground">
                    Tüm Ürünler
                  </h2>
                  <p className="text-sm text-muted-foreground mt-1">
                    {products.length} ürün
                  </p>
                </div>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
                {products.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            </div>
          </section>

          {/* About Section */}
          <section id="about" className="py-16 md:py-24 bg-card">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
              <div className="max-w-3xl mx-auto text-center">
                <span className="text-sm font-medium text-muted-foreground uppercase tracking-wider">
                  Hakkımızda
                </span>
                <h2 className="font-serif text-3xl md:text-4xl font-bold text-foreground mt-3 text-balance">
                  &quot;Kaliteli Tasarım, Mutlu Yaşam Alanları&quot;
                </h2>
                <p className="mt-6 text-muted-foreground leading-relaxed text-pretty">
                  Mağazamız, en kaliteli malzemelerle üretilmiş, özenle seçilmiş ev dekorasyon 
                  ürünlerini sizlere sunmaktadır. Her ürün, uzman zanaatkarlar tarafından 
                  titizlikle hazırlanmış olup, evinize değer katacak benzersiz parçalardır.
                </p>
              </div>
            </div>
          </section>
        </main>

        <Footer />
      </div>
    </CartProvider>
  )
}
