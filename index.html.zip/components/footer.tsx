export function Footer() {
  return (
    <footer className="border-t border-border bg-card mt-auto">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h2 className="font-serif text-xl font-bold text-foreground mb-4">Mağaza</h2>
            <p className="text-sm text-muted-foreground leading-relaxed">
              El yapımı ve özenle seçilmiş ürünlerle evinizi güzelleştirin. 
              Kalite ve zarafet bir arada.
            </p>
          </div>
          
          <div>
            <h3 className="font-medium text-foreground mb-4">Hızlı Linkler</h3>
            <ul className="space-y-2">
              <li>
                <a href="#products" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                  Ürünler
                </a>
              </li>
              <li>
                <a href="#about" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                  Hakkımızda
                </a>
              </li>
              <li>
                <a href="#contact" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                  İletişim
                </a>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-medium text-foreground mb-4">İletişim</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>info@magaza.com</li>
              <li>+90 (212) 555 0123</li>
              <li>İstanbul, Türkiye</li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-border mt-8 pt-8 text-center">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} Mağaza. Tüm hakları saklıdır.
          </p>
        </div>
      </div>
    </footer>
  )
}
