"use client"

import Image from "next/image"
import { ShoppingBag, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useCart, type Product } from "@/lib/cart-context"
import { cn } from "@/lib/utils"

interface ProductCardProps {
  product: Product
}

export function ProductCard({ product }: ProductCardProps) {
  const { addToCart, isInCart } = useCart()
  const inCart = isInCart(product.id)

  return (
    <div className="group">
      <div className="relative aspect-square overflow-hidden rounded-lg bg-secondary mb-4">
        <Image
          src={product.image}
          alt={product.name}
          fill
          className="object-cover transition-transform duration-500 group-hover:scale-105"
          sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
        />
        <div className="absolute top-3 left-3">
          <span className="inline-flex items-center justify-center px-2.5 py-1 text-xs font-medium bg-card text-card-foreground rounded-full shadow-sm">
            {product.id}
          </span>
        </div>
        <div className="absolute inset-0 bg-foreground/0 group-hover:bg-foreground/5 transition-colors duration-300" />
      </div>
      
      <div className="space-y-2">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <h3 className="font-serif text-lg font-medium text-foreground leading-tight">
              {product.name}
            </h3>
            <p className="text-sm text-muted-foreground mt-1 line-clamp-1">
              {product.description}
            </p>
          </div>
        </div>
        
        <div className="flex items-center justify-between gap-3">
          <span className="text-lg font-semibold text-foreground">
            ₺{product.price.toLocaleString("tr-TR")}
          </span>
          <Button
            size="sm"
            variant={inCart ? "secondary" : "default"}
            onClick={() => addToCart(product)}
            className={cn(
              "transition-all duration-200",
              inCart && "text-accent"
            )}
          >
            {inCart ? (
              <>
                <Check className="h-4 w-4 mr-1.5" />
                Sepette
              </>
            ) : (
              <>
                <ShoppingBag className="h-4 w-4 mr-1.5" />
                Sepete Ekle
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  )
}
