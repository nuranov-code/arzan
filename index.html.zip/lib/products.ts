import { Product } from "./cart-context"

export const products: Product[] = [
  {
    id: "A1",
    name: "El Yapımı Seramik Vazo",
    price: 450,
    image: "https://images.unsplash.com/photo-1578500494198-246f612d3b3d?w=500&q=80",
    description: "Zarif tasarım, her mekana uyum sağlar"
  },
  {
    id: "A2",
    name: "Organik Pamuk Yastık",
    price: 220,
    image: "https://images.unsplash.com/photo-1629949009765-f6d8b0e3a1c4?w=500&q=80",
    description: "Doğal ve konforlu uyku deneyimi"
  },
  {
    id: "A3",
    name: "Ahşap Dekoratif Tepsi",
    price: 180,
    image: "https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?w=500&q=80",
    description: "El işçiliği ile üretilmiş ceviz ahşap"
  },
  {
    id: "A4",
    name: "Minimalist Masa Lambası",
    price: 650,
    image: "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=500&q=80",
    description: "Modern tasarım, sıcak aydınlatma"
  },
  {
    id: "A5",
    name: "Dokuma Battaniye",
    price: 380,
    image: "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=500&q=80",
    description: "Yumuşak dokulu, her mevsim kullanılabilir"
  },
  {
    id: "A6",
    name: "Cam Dekoratif Kase",
    price: 290,
    image: "https://images.unsplash.com/photo-1584589167171-541ce45f1eea?w=500&q=80",
    description: "El üflemesi cam, benzersiz desen"
  },
  {
    id: "B1",
    name: "Hasır Sepet Seti",
    price: 340,
    image: "https://images.unsplash.com/photo-1599643477877-530eb83abc8e?w=500&q=80",
    description: "Doğal malzeme, 3 parça set"
  },
  {
    id: "B2",
    name: "Duvar Aynası",
    price: 520,
    image: "https://images.unsplash.com/photo-1618220179428-22790b461013?w=500&q=80",
    description: "Şık çerçeve tasarımı"
  },
  {
    id: "B3",
    name: "Porselen Fincan Takımı",
    price: 275,
    image: "https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?w=500&q=80",
    description: "6 kişilik, zarif detaylar"
  },
]
